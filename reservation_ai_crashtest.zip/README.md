# Reservation AI Crash Test

Prototype simple pour gérer des réservations par API REST.